from typing import List

from rdflib import DCTERMS, RDF, BNode, Graph, URIRef
from rdflib.resource import Resource

from scaffold import context
from scaffold.utils import SLOWMO
from scaffold.utils.namespace._PSDO import PSDO


def candidates(
    performer_graph: Graph, measure: BNode = None, filter_acceptable: bool = False
) -> List[Resource]:
    """
    Retrieve a list of candidate resources from the performer graph.

    Parameters:
        performer_graph (Graph): The performer_graph.
        measure (BNode, optional): The measure to filter candidates. Defaults to None.
        filter_acceptable (bool, optional): Whether to filter candidates based on acceptability. Defaults to False.

    Returns:
        List[Resource]: A list of candidate BNodes.
    """

    candidates = [
        performer_graph.resource(subject)
        for subject in performer_graph.subjects(RDF.type, SLOWMO.Candidate)
    ]

    candidates = [
        candidate
        for candidate in candidates
        if (
            (
                measure is None
                or candidate.value(SLOWMO.RegardingMeasure).identifier == measure
            )
            and (
                not filter_acceptable
                or candidate.value(SLOWMO.AcceptableBy) is not None
            )
        )
    ]

    return candidates

